﻿using AuthApp.Services;
using AuthApp.Services.Interfaces;
using AuthApp.Utils;

namespace AuthApp.Extensions
{
    public static class ServiceExtensions
    {
        public static IServiceCollection AddAppService(this IServiceCollection services)
        {
            services.AddScoped<CreateJWT>();
            services.AddScoped<IUserService, UserService>();

            return services;
        }
    }
}
