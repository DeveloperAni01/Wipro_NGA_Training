﻿using Scalar.AspNetCore;

namespace AuthApp.Extensions
{
    public static class ConfigureScalarApi
    {
        public static WebApplication ConfigureScalarApiRef(this WebApplication app)
        {
            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.MapOpenApi();
                app.MapScalarApiReference();
            }

            return app;
        }
    }
}
