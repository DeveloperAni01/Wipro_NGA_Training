﻿using AuthApp.Data;
using Microsoft.EntityFrameworkCore;

namespace AuthApp.Extensions
{
    public static class EFCoreExtentions
    {
        public static IServiceCollection InjectDbContext (this IServiceCollection services, IConfiguration config)
        {
           services.AddDbContext<ApplicationDbContext>(options => options.UseSqlServer(config.GetConnectionString("DefaultConnection")));
            return services;
        }
    }
}
