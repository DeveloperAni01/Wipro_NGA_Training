using AuthApp.Extensions;


var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
builder.Services.AddOpenApi();

//maintaining order is necessary
builder.Services.InjectDbContext(builder.Configuration)
    .AddIdentityHandlersAndStores()
    .ConfigureIdentityOptions()
    .AddIdentityAuth(builder.Configuration)
    .AddAppService();


var app = builder.Build();

app.ConfigureScalarApiRef()
    .UseHttpsRedirection();

app.ConfigureCORS(builder.Configuration)
    .AddIdentityAuthMiddlewares();


app.MapControllers();


app.Run();
    
