﻿using System.ComponentModel.DataAnnotations;

namespace AuthApp.DTOs.Users
{
    public class UserRegisterDto
    {
        [Required]
        public string FullName { get; set; }
        [Required]
        public string Email { get; set; }
        [Required]
        public string Password { get; set; }

    }
}
