﻿using System.ComponentModel.DataAnnotations;

namespace AuthApp.DTOs.Users
{
    public class UserLoginDto
    {
        [Required]
        public string Email { get; set; }
        [Required]
        public string Password { get; set; }
        
    }
}
