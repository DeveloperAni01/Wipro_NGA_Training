﻿using AuthApp.DTOs.Users;
using AuthApp.Models;
using AuthApp.Services.Interfaces;
using AuthApp.Utils;
using Microsoft.AspNetCore.Identity;

namespace AuthApp.Services
{
    public class UserService : IUserService
    {
        private readonly UserManager<AppUser> _userManager;
        private readonly CreateJWT _createJWT;
        public UserService(UserManager<AppUser> userManager, CreateJWT createJWT)
        {
            _userManager = userManager;
            _createJWT = createJWT;

        }

        public async Task<string> UserLogin(UserLoginDto request)
        {
            // ✅ Fixed: was checking `userReq == null` AFTER already using it
            var user = await _userManager.FindByEmailAsync(request.Email)
                ?? throw new Exception("User not found!");

            var validPassword = await _userManager.CheckPasswordAsync(user, request.Password);
            if (!validPassword)
                throw new Exception("Invalid credentials!");

            // ✅ Generate and return token via injected service
            return _createJWT.GenerateToken(user);
        }

        public async Task<AppUser> UserRegistration(UserRegisterDto request)
        {
            var newUser = new AppUser
            {
                Email = request.Email,
                FullName = request.FullName,
                UserName = request.Email,

            };
            var result = await _userManager.CreateAsync(newUser, request.Password);

            if (!result.Succeeded)
                throw new Exception(string.Join(", ", result.Errors.Select(e => e.Description)));

            return newUser;
        }

    }
}
