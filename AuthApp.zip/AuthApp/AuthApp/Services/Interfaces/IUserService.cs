﻿using AuthApp.DTOs.Users;
using AuthApp.Models;

namespace AuthApp.Services.Interfaces
{
    public interface IUserService
    {
        public Task<AppUser> UserRegistration(UserRegisterDto request);
        Task<string> UserLogin(UserLoginDto request);
    }
}
