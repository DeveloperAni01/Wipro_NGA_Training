﻿using AuthApp.DTOs.Users;
using AuthApp.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace AuthApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly IUserService _userService;

        public AuthController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpPost("signup")]
        public async Task<IActionResult> UserRegister(UserRegisterDto user)
        {
            try
            {
                var newUser = await _userService.UserRegistration(user);
                return Ok(new { message = "User registered successfully", username = newUser.UserName });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpPost("signin")]
        public async Task<IActionResult> UserSignin(UserLoginDto user)
        {
            try
            {
                var token = await _userService.UserLogin(user);
                return Ok(new { message = "Login successful!", userAuthToken = token });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }
    }
}