import { Component, signal } from '@angular/core';


@Component({
  selector: 'app-root',
  imports: [],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
  
export class App {
  // name = ""
  // username = ""
  // getName(event: Event) {
  //   this.name = (event.target as HTMLInputElement).value;
  // }

  // setName() {
    
  //   this.username = this.name
  // }

  // email = ""
  // getEmail(value:string) {
  //  this.email = value
    
  // }

  count = signal(10)
  x=20
  
}
