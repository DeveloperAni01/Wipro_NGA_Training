import { Component } from "@angular/core";

@Component({
  selector: "app-customComponent",
  template:`<h1>customComponent</h1>`
})

export class customComponent{

}
