import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Login } from './login/login';
import { customComponent } from './customComponent/customComponent';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,Login,customComponent],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('myFirstAngApp');
  func() {
    console.log("Button clicked");
  }
  sum(a:number, b:number){
  console.log(a+b);

  }


}
