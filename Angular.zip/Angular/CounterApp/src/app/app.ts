import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Events } from './events/events';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,Events],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  count = 0;
  handleCounter(val: string) {
    if (val == '+') {
      this.count++;
    } else if (val == '-') {
      if (this.count > 0) this.count--;
    } else {
      this.count = 0;
    }
  }
}
