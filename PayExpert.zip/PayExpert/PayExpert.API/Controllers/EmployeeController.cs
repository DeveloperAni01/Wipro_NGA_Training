﻿using Asp.Versioning;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PayXpert.Application.DTOs.Common;
using PayXpert.Application.DTOs.Employee;
using PayXpert.Application.Interfaces;
using PayXpert.Domain.Entities;

namespace PayXpert.API.Controllers
{
    [ApiController]
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}/[controller]")]
    [Authorize]
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployeeService _employeeService;
        private readonly ILogger<EmployeeController> _logger;

        public EmployeeController(IEmployeeService employeeService, ILogger<EmployeeController> logger)
        {
            _employeeService = employeeService;
            _logger = logger;
        }

        // ── GET: api/v1/employee ──────────────────────────────
        // HRManager and above can view all employees
        [HttpGet]
        [Authorize(Policy = "HRManagerOrAbove")]
        public async Task<IActionResult> GetAllEmployees()
        {
            _logger.LogInformation("Fetching all employees.");

            var employees = await _employeeService.GetAllEmployeesAsync();

            var result = employees.Select(e => new EmployeeSummaryDto
            {
                EmployeeID = e.EmployeeID,
                FullName = $"{e.FirstName} {e.LastName}",
                Position = e.Position,
                Email = e.Email,
                IsActive = e.IsActive
            });

            return Ok(ApiResponse<IEnumerable<EmployeeSummaryDto>>
                .SuccessResponse(result, "Employees retrieved successfully."));
        }

        // ── GET: api/v1/employee/{id} ─────────────────────────
        // All authenticated users can fetch — service layer
        // will enforce own-record rule later
        [HttpGet("{id}")]
        [Authorize(Policy = "AllRoles")]
        public async Task<IActionResult> GetEmployeeById(string id)
        {
            _logger.LogInformation("Fetching employee with ID: {Id}", id);

            var employee = await _employeeService.GetEmployeeByIdAsync(id);

            var result = MapToResponseDto(employee);

            return Ok(ApiResponse<EmployeeResponseDto>
                .SuccessResponse(result, "Employee retrieved successfully."));
        }

        // ── POST: api/v1/employee ─────────────────────────────
        // Only HRManager and above can add employees
        [HttpPost]
        [Authorize(Policy = "HRManagerOrAbove")]
        public async Task<IActionResult> AddEmployee([FromBody] CreateEmployeeRequestDto dto)
        {
            _logger.LogInformation("Adding new employee: {Email}", dto.Email);

            var employee = new Employee
            {
                FirstName = dto.FirstName,
                LastName = dto.LastName,
                DateOfBirth = dto.DateOfBirth,
                Gender = dto.Gender,
                Email = dto.Email,
                PhoneNumber = dto.PhoneNumber,
                Address = dto.Address,
                Position = dto.Position,
                JoiningDate = dto.JoiningDate,
                CreatedBy = User.Identity?.Name ?? "System"
            };

            var created = await _employeeService.AddEmployeeAsync(employee);
            var result = MapToResponseDto(created);

            return CreatedAtAction(
                nameof(GetEmployeeById),
                new { id = created.EmployeeID },
                ApiResponse<EmployeeResponseDto>.SuccessResponse(result, "Employee added successfully.")
            );
        }

        // ── PUT: api/v1/employee/{id} ─────────────────────────
        // Only HRManager and above can update employees
        [HttpPut("{id}")]
        [Authorize(Policy = "HRManagerOrAbove")]
        public async Task<IActionResult> UpdateEmployee(string id, [FromBody] UpdateEmployeeRequestDto dto)
        {
            if (id != dto.EmployeeID)
                return BadRequest(ApiResponse.FailureResponse("ID in URL does not match ID in body."));

            _logger.LogInformation("Updating employee: {Id}", id);

            var employee = new Employee
            {
                EmployeeID = dto.EmployeeID,
                FirstName = dto.FirstName,
                LastName = dto.LastName,
                Gender = dto.Gender,
                Email = dto.Email,
                PhoneNumber = dto.PhoneNumber,
                Address = dto.Address,
                Position = dto.Position
            };

            var updated = await _employeeService.UpdateEmployeeAsync(employee);
            var result = MapToResponseDto(updated);

            return Ok(ApiResponse<EmployeeResponseDto>
                .SuccessResponse(result, "Employee updated successfully."));
        }

        // ── DELETE: api/v1/employee/{id}/soft ────────────────
        // HRManager and above can soft delete
        [HttpDelete("{id}/soft")]
        [Authorize(Policy = "HRManagerOrAbove")]
        public async Task<IActionResult> SoftDeleteEmployee(string id)
        {
            _logger.LogInformation("Soft deleting employee: {Id}", id);

            var deletedBy = User.Identity?.Name ?? "System";
            await _employeeService.SoftDeleteEmployeeAsync(id, deletedBy);

            return Ok(ApiResponse.SuccessResponse("Employee deactivated successfully."));
        }

        // ── DELETE: api/v1/employee/{id}/hard ────────────────
        // Only SuperAdmin can hard delete
        [HttpDelete("{id}/hard")]
        [Authorize(Policy = "SuperAdminOnly")]
        public async Task<IActionResult> HardDeleteEmployee(string id)
        {
            _logger.LogWarning("Hard deleting employee: {Id} — this is irreversible!", id);

            await _employeeService.HardDeleteEmployeeAsync(id);

            return Ok(ApiResponse.SuccessResponse("Employee permanently deleted."));
        }

        // ── Private: Map Entity to Response DTO ───────────────
        private static EmployeeResponseDto MapToResponseDto(Employee e) => new()
        {
            EmployeeID = e.EmployeeID,
            FirstName = e.FirstName,
            LastName = e.LastName,
            DateOfBirth = e.DateOfBirth,
            Gender = e.Gender,
            Email = e.Email,
            PhoneNumber = e.PhoneNumber,
            Address = e.Address,
            Position = e.Position,
            JoiningDate = e.JoiningDate,
            TerminationDate = e.TerminationDate,
            IsActive = e.IsActive,
            CreatedAt = e.CreatedAt,
            CreatedBy = e.CreatedBy
        };
    }
}