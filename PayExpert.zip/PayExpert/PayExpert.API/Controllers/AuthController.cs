﻿using Asp.Versioning;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using PayXpert.Application.DTOs.Auth;
using PayXpert.Application.DTOs.Common;
using PayXpert.Infrastructure.Identity;
using PayXpert.Infrastructure.Services;

namespace PayXpert.API.Controllers
{
    [ApiController]
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly TokenService _tokenService;
        private readonly ILogger<AuthController> _logger;
        private readonly IConfiguration _configuration;

        public AuthController(
            UserManager<ApplicationUser> userManager,
            SignInManager<ApplicationUser> signInManager,
            RoleManager<IdentityRole> roleManager,
            TokenService tokenService,
            ILogger<AuthController> logger,
            IConfiguration configuration)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _roleManager = roleManager;
            _tokenService = tokenService;
            _logger = logger;
            _configuration = configuration;
        }

        // ── POST: api/v1/auth/register ────────────────────────
        // Only SuperAdmin can register new users
        [HttpPost("register")]
        [Authorize(Policy = "SuperAdminOnly")]
        public async Task<IActionResult> Register([FromBody] RegisterRequestDto dto)
        {
            _logger.LogInformation("Registering new user: {Email}", dto.Email);

            // Validate role
            var validRoles = new[] { "SuperAdmin", "HRManager", "Manager", "Employee" };
            if (!validRoles.Contains(dto.Role))
                return BadRequest(ApiResponse.FailureResponse(
                    $"Invalid role '{dto.Role}'. Valid roles: {string.Join(", ", validRoles)}"));

            // Check role exists
            if (!await _roleManager.RoleExistsAsync(dto.Role))
                return BadRequest(ApiResponse.FailureResponse($"Role '{dto.Role}' does not exist."));

            // Create user
            var user = new ApplicationUser
            {
                UserName = dto.UserName,
                Email = dto.Email,
                EmployeeID = dto.EmployeeID,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow,
                IsActive = true
            };

            var result = await _userManager.CreateAsync(user, dto.Password);

            if (!result.Succeeded)
            {
                var errors = result.Errors.Select(e => e.Description).ToList();
                return BadRequest(ApiResponse.FailureResponse("User registration failed.", errors));
            }

            // Assign role
            await _userManager.AddToRoleAsync(user, dto.Role);

            _logger.LogInformation("User {Email} registered successfully with role {Role}.",
                dto.Email, dto.Role);

            var response = new RegisterResponseDto
            {
                UserID = user.Id,
                UserName = user.UserName!,
                Email = user.Email!,
                Role = dto.Role,
                EmployeeID = user.EmployeeID
            };

            return Ok(ApiResponse<RegisterResponseDto>
                .SuccessResponse(response, "User registered successfully."));
        }

        // ── POST: api/v1/auth/login ───────────────────────────
        // Public endpoint — no auth required
        [HttpPost("login")]
        [AllowAnonymous]
        public async Task<IActionResult> Login([FromBody] LoginRequestDto dto)
        {
            _logger.LogInformation("Login attempt for: {Email}", dto.Email);

            // Find user by email
            var user = await _userManager.FindByEmailAsync(dto.Email);
            if (user == null || !user.IsActive)
                return Unauthorized(ApiResponse.FailureResponse("Invalid email or password."));

            // Check password
            var result = await _signInManager.CheckPasswordSignInAsync(user, dto.Password, lockoutOnFailure: true);

            if (result.IsLockedOut)
                return Unauthorized(ApiResponse.FailureResponse(
                    "Account is locked out. Please try again after 15 minutes."));

            if (!result.Succeeded)
                return Unauthorized(ApiResponse.FailureResponse("Invalid email or password."));

            // Generate JWT token
            var token = await _tokenService.GenerateTokenAsync(user);
            var roles = await _userManager.GetRolesAsync(user);
            var expiry = int.Parse(_configuration["JwtSettings:ExpiryInMinutes"] ?? "60");

            // Update last login
            user.UpdatedAt = DateTime.UtcNow;
            await _userManager.UpdateAsync(user);

            _logger.LogInformation("User {Email} logged in successfully.", dto.Email);

            var response = new LoginResponseDto
            {
                Token = token,
                UserName = user.UserName!,
                Email = user.Email!,
                Role = roles.FirstOrDefault() ?? "Employee",
                EmployeeID = user.EmployeeID,
                ExpiresAt = DateTime.UtcNow.AddMinutes(expiry)
            };

            return Ok(ApiResponse<LoginResponseDto>
                .SuccessResponse(response, "Login successful."));
        }

        // ── POST: api/v1/auth/assign-role ─────────────────────
        // Only SuperAdmin can assign roles
        [HttpPost("assign-role")]
        [Authorize(Policy = "SuperAdminOnly")]
        public async Task<IActionResult> AssignRole([FromBody] AssignRoleRequestDto dto)
        {
            _logger.LogInformation("Assigning role {Role} to user {UserId}", dto.Role, dto.UserID);

            var user = await _userManager.FindByIdAsync(dto.UserID);
            if (user == null)
                return NotFound(ApiResponse.FailureResponse($"User with ID '{dto.UserID}' not found."));

            if (!await _roleManager.RoleExistsAsync(dto.Role))
                return BadRequest(ApiResponse.FailureResponse($"Role '{dto.Role}' does not exist."));

            // Remove existing roles first
            var existingRoles = await _userManager.GetRolesAsync(user);
            await _userManager.RemoveFromRolesAsync(user, existingRoles);

            // Assign new role
            await _userManager.AddToRoleAsync(user, dto.Role);

            _logger.LogInformation("Role {Role} assigned to user {UserId} successfully.",
                dto.Role, dto.UserID);

            return Ok(ApiResponse.SuccessResponse($"Role '{dto.Role}' assigned successfully."));
        }

        // ── POST: api/v1/auth/register-superadmin ─────────────
        // Special one-time endpoint to create the first SuperAdmin
        // Disable this in production after first use!
        [HttpPost("register-superadmin")]
        [AllowAnonymous]
        public async Task<IActionResult> RegisterSuperAdmin([FromBody] RegisterRequestDto dto)
        {
            // Only allow if no SuperAdmin exists yet
            var superAdminExists = await _userManager.GetUsersInRoleAsync("SuperAdmin");
            if (superAdminExists.Any())
                return BadRequest(ApiResponse.FailureResponse(
                    "SuperAdmin already exists. This endpoint is disabled."));

            _logger.LogWarning("Creating first SuperAdmin user: {Email}", dto.Email);

            var user = new ApplicationUser
            {
                UserName = dto.UserName,
                Email = dto.Email,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow,
                IsActive = true
            };

            var result = await _userManager.CreateAsync(user, dto.Password);

            if (!result.Succeeded)
            {
                var errors = result.Errors.Select(e => e.Description).ToList();
                return BadRequest(ApiResponse.FailureResponse("SuperAdmin creation failed.", errors));
            }

            await _userManager.AddToRoleAsync(user, "SuperAdmin");

            _logger.LogInformation("SuperAdmin created successfully: {Email}", dto.Email);

            var response = new RegisterResponseDto
            {
                UserID = user.Id,
                UserName = user.UserName!,
                Email = user.Email!,
                Role = "SuperAdmin"
            };

            return Ok(ApiResponse<RegisterResponseDto>
                .SuccessResponse(response, "SuperAdmin created successfully."));
        }
    }
}