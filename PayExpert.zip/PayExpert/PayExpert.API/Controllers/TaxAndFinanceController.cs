﻿using Asp.Versioning;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PayXpert.Application.DTOs.Common;
using PayXpert.Application.DTOs.Tax;
using PayXpert.Application.DTOs.FinancialRecord;
using PayXpert.Application.Interfaces;
using System.Net.WebSockets;

namespace PayXpert.API.Controllers
{
    // ════════════════════════════════════════════════════════════
    // TAX CONTROLLER
    // ════════════════════════════════════════════════════════════

    [ApiController]
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}/[controller]")]
    [Authorize]
    public class TaxController : ControllerBase
    {
        private readonly ITaxService _taxService;
        private readonly ILogger<TaxController> _logger;

        public TaxController(ITaxService taxService, ILogger<TaxController> logger)
        {
            _taxService = taxService;
            _logger = logger;
        }

        // ── POST: api/v1/tax/calculate ────────────────────────
        [HttpPost("calculate")]
        [Authorize(Policy = "HRManagerOrAbove")]
        public async Task<IActionResult> CalculateTax([FromBody] CalculateTaxRequestDto dto)
        {
            _logger.LogInformation("Calculating tax for employee: {Id}, year: {Year}",
                dto.EmployeeID, dto.TaxYear);

            var createdBy = User.Identity?.Name ?? "System";

            var tax = await _taxService.CalculateTaxAsync(dto.EmployeeID, dto.TaxYear);
            

            var result = new TaxResponseDto
            {
                TaxID = tax.TaxID,
                EmployeeID = tax.EmployeeID,
                TaxableIncome = tax.TaxableIncome,
                TaxAmount = tax.TaxAmount,
                CreatedAt = tax.CreatedAt,
                CreatedBy = createdBy
            };

            return Ok(ApiResponse<TaxResponseDto>
                .SuccessResponse(result, "Tax calculated successfully."));
        }

        // ── GET: api/v1/tax/{id} ──────────────────────────────
        [HttpGet("{id}")]
        [Authorize(Policy = "HRManagerOrAbove")]
        public async Task<IActionResult> GetTaxById(string id)
        {
            _logger.LogInformation("Fetching tax record: {Id}", id);

            var tax = await _taxService.GetTaxByIdAsync(id);

            var result = new TaxResponseDto
            {
                TaxID = tax.TaxID,
                EmployeeID = tax.EmployeeID,
                EmployeeFullName = $"{tax.Employee?.FirstName} {tax.Employee?.LastName}",
                TaxYear = tax.TaxYear,
                TaxableIncome = tax.TaxableIncome,
                TaxAmount = tax.TaxAmount,
                CreatedAt = tax.CreatedAt,
                CreatedBy = tax.CreatedBy
            };

            return Ok(ApiResponse<TaxResponseDto>
                .SuccessResponse(result, "Tax record retrieved successfully."));
        }

        // ── GET: api/v1/tax/employee/{employeeId} ─────────────
        [HttpGet("employee/{employeeId}")]
        [Authorize(Policy = "AllRoles")]
        public async Task<IActionResult> GetTaxesForEmployee(string employeeId)
        {
            _logger.LogInformation("Fetching tax records for employee: {Id}", employeeId);

            var taxes = await _taxService.GetTaxesForEmployeeAsync(employeeId);

            var result = taxes.Select(t => new TaxSummaryDto
            {
                TaxID = t.TaxID,
                EmployeeID = t.EmployeeID,
                TaxYear = t.TaxYear,
                TaxAmount = t.TaxAmount,
                EmployeeFullName = $"{ t.Employee?.FirstName} {t.Employee?.LastName}"

            });

            return Ok(ApiResponse<IEnumerable<TaxSummaryDto>>
                .SuccessResponse(result, "Tax records retrieved successfully."));
        }

        // ── GET: api/v1/tax/year/{year} ───────────────────────
        [HttpGet("year/{year}")]
        [Authorize(Policy = "HRManagerOrAbove")]
        public async Task<IActionResult> GetTaxesForYear(int year)
        {
            _logger.LogInformation("Fetching all tax records for year: {Year}", year);

            var taxes = await _taxService.GetTaxesForYearAsync(year);

            var result = taxes.Select(t => new TaxSummaryDto
            {
                TaxID = t.TaxID,
                EmployeeID = t.EmployeeID,
                EmployeeFullName = $"{t.Employee?.FirstName} {t.Employee?.LastName}",
                TaxYear = t.TaxYear,
                TaxAmount = t.TaxAmount
            });

            return Ok(ApiResponse<IEnumerable<TaxSummaryDto>>
                .SuccessResponse(result, "Tax records retrieved successfully."));
        }
    }

    // ════════════════════════════════════════════════════════════
    // FINANCIAL RECORD CONTROLLER
    // ════════════════════════════════════════════════════════════

    [ApiController]
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}/[controller]")]
    [Authorize]
    public class FinancialRecordController : ControllerBase
    {
        private readonly IFinancialRecordService _financialRecordService;
        private readonly ILogger<FinancialRecordController> _logger;

        public FinancialRecordController(
            IFinancialRecordService financialRecordService,
            ILogger<FinancialRecordController> logger)
        {
            _financialRecordService = financialRecordService;
            _logger = logger;
        }

        // ── POST: api/v1/financialrecord ──────────────────────
        [HttpPost]
        [Authorize(Policy = "HRManagerOrAbove")]
        public async Task<IActionResult> AddFinancialRecord([FromBody] AddFinancialRecordRequestDto dto)
        {
            _logger.LogInformation("Adding financial record for employee: {Id}", dto.EmployeeID);

            var createdBy = User.Identity?.Name ?? "System";

            var record = await _financialRecordService.AddFinancialRecordAsync(
                dto.EmployeeID,
                dto.Description,
                dto.Amount,
                dto.RecordType,
                createdBy
            );

            var result = new FinancialRecordResponseDto
            {
                RecordID = record.RecordID,
                EmployeeID = record.EmployeeID,
                RecordDate = record.RecordDate,
                Description = record.Description,
                Amount = record.Amount,
                RecordType = record.RecordType,
                CreatedAt = record.CreatedAt,
                CreatedBy = record.CreatedBy
            };

            return Ok(ApiResponse<FinancialRecordResponseDto>
                .SuccessResponse(result, "Financial record added successfully."));
        }

        // ── GET: api/v1/financialrecord/{id} ──────────────────
        [HttpGet("{id}")]
        [Authorize(Policy = "HRManagerOrAbove")]
        public async Task<IActionResult> GetFinancialRecordById(string id)
        {
            _logger.LogInformation("Fetching financial record: {Id}", id);

            var record = await _financialRecordService.GetFinancialRecordByIdAsync(id);

            var result = new FinancialRecordResponseDto
            {
                RecordID = record.RecordID,
                EmployeeID = record.EmployeeID,
                EmployeeFullName = $"{record.Employee?.FirstName} {record.Employee?.LastName}",
                RecordDate = record.RecordDate,
                Description = record.Description,
                Amount = record.Amount,
                RecordType = record.RecordType,
                CreatedAt = record.CreatedAt,
                CreatedBy = record.CreatedBy
            };

            return Ok(ApiResponse<FinancialRecordResponseDto>
                .SuccessResponse(result, "Financial record retrieved successfully."));
        }

        // ── GET: api/v1/financialrecord/employee/{employeeId} ─
        [HttpGet("employee/{employeeId}")]
        [Authorize(Policy = "AllRoles")]
        public async Task<IActionResult> GetFinancialRecordsForEmployee(string employeeId)
        {
            _logger.LogInformation("Fetching financial records for employee: {Id}", employeeId);

            var records = await _financialRecordService
                .GetFinancialRecordsForEmployeeAsync(employeeId);

            var result = records.Select(r => new FinancialRecordSummaryDto
            {
                RecordID = r.RecordID,
                EmployeeID = r.EmployeeID,
                RecordDate = r.RecordDate,
                RecordType = r.RecordType,
                Amount = r.Amount
            });

            return Ok(ApiResponse<IEnumerable<FinancialRecordSummaryDto>>
                .SuccessResponse(result, "Financial records retrieved successfully."));
        }

        // ── GET: api/v1/financialrecord/date?date= ────────────
        [HttpGet("date")]
        [Authorize(Policy = "HRManagerOrAbove")]
        public async Task<IActionResult> GetFinancialRecordsForDate([FromQuery] DateTime date)
        {
            _logger.LogInformation("Fetching financial records for date: {Date}", date);

            var records = await _financialRecordService
                .GetFinancialRecordsForDateAsync(date);

            var result = records.Select(r => new FinancialRecordSummaryDto
            {
                RecordID = r.RecordID,
                EmployeeID = r.EmployeeID,
                RecordDate = r.RecordDate,
                RecordType = r.RecordType,
                Amount = r.Amount
            });

            return Ok(ApiResponse<IEnumerable<FinancialRecordSummaryDto>>
                .SuccessResponse(result, "Financial records retrieved successfully."));
        }
    }
}