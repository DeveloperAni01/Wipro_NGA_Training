﻿using Asp.Versioning;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PayXpert.Application.DTOs.Common;
using PayXpert.Application.DTOs.Payroll;
using PayXpert.Application.Interfaces;

namespace PayXpert.API.Controllers
{
    [ApiController]
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}/[controller]")]
    [Authorize]
    public class PayrollController : ControllerBase
    {
        private readonly IPayrollService _payrollService;
        private readonly ILogger<PayrollController> _logger;

        public PayrollController(IPayrollService payrollService, ILogger<PayrollController> logger)
        {
            _payrollService = payrollService;
            _logger = logger;
        }

        // ── POST: api/v1/payroll/generate ─────────────────────
        [HttpPost("generate")]
        [Authorize(Policy = "HRManagerOrAbove")]
        public async Task<IActionResult> GeneratePayroll([FromBody] GeneratePayrollRequestDto dto)
        {
            _logger.LogInformation("Generating payroll for employee: {Id}", dto.EmployeeID);

            var payroll = await _payrollService.GeneratePayrollAsync(
                dto.EmployeeID,
                dto.PayPeriodStartDate,
                dto.PayPeriodEndDate,
                dto.BasicSalary,
                dto.OvertimePay,
                dto.Deductions
            );

            var result = new PayrollResponseDto
            {
                PayrollID = payroll.PayrollID,
                EmployeeID = payroll.EmployeeID,
                PayPeriodStartDate = payroll.PayPeriodStartDate,
                PayPeriodEndDate = payroll.PayPeriodEndDate,
                BasicSalary = payroll.BasicSalary,
                OvertimePay = payroll.OvertimePay,
                Deductions = payroll.Deductions,
                NetSalary = payroll.NetSalary,
                CreatedAt = payroll.CreatedAt,
                CreatedBy = payroll.CreatedBy
            };

            return Ok(ApiResponse<PayrollResponseDto>
                .SuccessResponse(result, "Payroll generated successfully."));
        }

        // ── GET: api/v1/payroll/{id} ──────────────────────────
        [HttpGet("{id}")]
        [Authorize(Policy = "HRManagerOrAbove")]
        public async Task<IActionResult> GetPayrollById(string id)
        {
            _logger.LogInformation("Fetching payroll: {Id}", id);

            var payroll = await _payrollService.GetPayrollByIdAsync(id);

            var result = new PayrollResponseDto
            {
                PayrollID = payroll.PayrollID,
                EmployeeID = payroll.EmployeeID,
                EmployeeFullName = $"{payroll.Employee?.FirstName} {payroll.Employee?.LastName}",
                PayPeriodStartDate = payroll.PayPeriodStartDate,
                PayPeriodEndDate = payroll.PayPeriodEndDate,
                BasicSalary = payroll.BasicSalary,
                OvertimePay = payroll.OvertimePay,
                Deductions = payroll.Deductions,
                NetSalary = payroll.NetSalary,
                CreatedAt = payroll.CreatedAt,
                CreatedBy = payroll.CreatedBy
            };

            return Ok(ApiResponse<PayrollResponseDto>
                .SuccessResponse(result, "Payroll retrieved successfully."));
        }

        // ── GET: api/v1/payroll/employee/{employeeId} ─────────
        [HttpGet("employee/{employeeId}")]
        [Authorize(Policy = "AllRoles")]
        public async Task<IActionResult> GetPayrollsForEmployee(string employeeId)
        {
            _logger.LogInformation("Fetching payrolls for employee: {Id}", employeeId);

            var payrolls = await _payrollService.GetPayrollsForEmployeeAsync(employeeId);

            var result = payrolls.Select(p => new PayrollSummaryDto
            {
                PayrollID = p.PayrollID,
                EmployeeID = p.EmployeeID,
                PayPeriodStartDate = p.PayPeriodStartDate,
                PayPeriodEndDate = p.PayPeriodEndDate,
                NetSalary = p.NetSalary
            });

            return Ok(ApiResponse<IEnumerable<PayrollSummaryDto>>
                .SuccessResponse(result, "Payrolls retrieved successfully."));
        }

        // ── GET: api/v1/payroll/period?start=&end= ────────────
        [HttpGet("period")]
        [Authorize(Policy = "HRManagerOrAbove")]
        public async Task<IActionResult> GetPayrollsForPeriod(
            [FromQuery] DateTime start,
            [FromQuery] DateTime end)
        {
            _logger.LogInformation("Fetching payrolls from {Start} to {End}", start, end);

            var payrolls = await _payrollService.GetPayrollsForPeriodAsync(start, end);

            var result = payrolls.Select(p => new PayrollSummaryDto
            {
                PayrollID = p.PayrollID,
                EmployeeID = p.EmployeeID,
                EmployeeFullName = $"{p.Employee?.FirstName} {p.Employee?.LastName}",
                PayPeriodStartDate = p.PayPeriodStartDate,
                PayPeriodEndDate = p.PayPeriodEndDate,
                NetSalary = p.NetSalary
            });

            return Ok(ApiResponse<IEnumerable<PayrollSummaryDto>>
                .SuccessResponse(result, "Payrolls retrieved successfully."));
        }
    }
}