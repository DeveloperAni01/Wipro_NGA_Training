﻿using System.Net;
using System.Text.Json;
using PayXpert.Application.DTOs.Common;
using PayXpert.Infrastructure.Exceptions;

namespace PayXpert.API.Middleware
{
    public class GlobalExceptionMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<GlobalExceptionMiddleware> _logger;

        public GlobalExceptionMiddleware(RequestDelegate next, ILogger<GlobalExceptionMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unhandled exception: {Message}", ex.Message);
                await HandleExceptionAsync(context, ex);
            }
        }

        private static async Task HandleExceptionAsync(HttpContext context, Exception exception)
        {
            context.Response.ContentType = "application/json";

            var (statusCode, message) = exception switch
            {
                EmployeeNotFoundException => (HttpStatusCode.NotFound, exception.Message),
                PayrollGenerationException => (HttpStatusCode.BadRequest, exception.Message),
                TaxCalculationException => (HttpStatusCode.BadRequest, exception.Message),
                FinancialRecordException => (HttpStatusCode.BadRequest, exception.Message),
                InvalidInputException => (HttpStatusCode.BadRequest, exception.Message),
                DatabaseConnectionException => (HttpStatusCode.ServiceUnavailable, exception.Message),
                UnauthorizedAccessException => (HttpStatusCode.Unauthorized, "You are not authorized to perform this action."),
                _ => (HttpStatusCode.InternalServerError, "An unexpected error occurred. Please try again later.")
            };

            context.Response.StatusCode = (int)statusCode;

            var response = ApiResponse.FailureResponse(message);

            var json = JsonSerializer.Serialize(response, new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase
            });

            await context.Response.WriteAsync(json);
        }
    }
}