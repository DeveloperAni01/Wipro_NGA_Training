﻿namespace PayXpert.Application.DTOs.Auth
{
    // ── Request DTOs ──────────────────────────────────────────

    public class RegisterRequestDto
    {
        public string UserName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
        public string Role { get; set; } = string.Empty;

        // Optional — link to an existing employee
        public string? EmployeeID { get; set; }
    }

    public class LoginRequestDto
    {
        public string Email { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
    }

    public class AssignRoleRequestDto
    {
        public string UserID { get; set; } = string.Empty;
        public string Role { get; set; } = string.Empty;
    }

    // ── Response DTOs ─────────────────────────────────────────

    public class LoginResponseDto
    {
        public string Token { get; set; } = string.Empty;
        public string UserName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Role { get; set; } = string.Empty;
        public string? EmployeeID { get; set; }
        public DateTime ExpiresAt { get; set; }
    }

    public class RegisterResponseDto
    {
        public string UserID { get; set; } = string.Empty;
        public string UserName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Role { get; set; } = string.Empty;
        public string? EmployeeID { get; set; }
    }
}