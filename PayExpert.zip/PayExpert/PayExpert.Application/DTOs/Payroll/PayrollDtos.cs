﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PayXpert.Application.DTOs.Payroll
{
    // ── Request DTOs ──────────────────────────────────────────

    public class GeneratePayrollRequestDto
    {
        public string EmployeeID { get; set; } = string.Empty;
        public DateTime PayPeriodStartDate { get; set; }
        public DateTime PayPeriodEndDate { get; set; }
        public decimal BasicSalary { get; set; }
        public decimal OvertimePay { get; set; }
        public decimal Deductions { get; set; }
    }

    // ── Response DTOs ─────────────────────────────────────────

    public class PayrollResponseDto
    {
        public string PayrollID { get; set; } = string.Empty;
        public string EmployeeID { get; set; } = string.Empty;
        public string EmployeeFullName { get; set; } = string.Empty;
        public DateTime PayPeriodStartDate { get; set; }
        public DateTime PayPeriodEndDate { get; set; }
        public decimal BasicSalary { get; set; }
        public decimal OvertimePay { get; set; }
        public decimal Deductions { get; set; }
        public decimal GrossSalary => BasicSalary + OvertimePay;
        public decimal NetSalary { get; set; }
        public DateTime CreatedAt { get; set; }
        public string CreatedBy { get; set; } = string.Empty;
    }

    public class PayrollSummaryDto
    {
        public string PayrollID { get; set; } = string.Empty;
        public string EmployeeID { get; set; } = string.Empty;
        public string EmployeeFullName { get; set; } = string.Empty;
        public DateTime PayPeriodStartDate { get; set; }
        public DateTime PayPeriodEndDate { get; set; }
        public decimal NetSalary { get; set; }
    }
}
