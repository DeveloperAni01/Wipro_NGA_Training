﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PayXpert.Application.DTOs.Common
{
    // ── Standard API Response Wrapper ─────────────────────────
    // Every single API endpoint returns this wrapper
    // so the frontend always gets a consistent shape

    public class ApiResponse<T>
    {
        public bool Success { get; set; }
        public string Message { get; set; } = string.Empty;
        public T? Data { get; set; }
        public List<string> Errors { get; set; } = new();

        // ── Static factory methods ────────────────────────────

        public static ApiResponse<T> SuccessResponse(T data, string message = "Operation successful.")
        {
            return new ApiResponse<T>
            {
                Success = true,
                Message = message,
                Data = data,
                Errors = new List<string>()
            };
        }

        public static ApiResponse<T> FailureResponse(string message, List<string>? errors = null)
        {
            return new ApiResponse<T>
            {
                Success = false,
                Message = message,
                Data = default,
                Errors = errors ?? new List<string>()
            };
        }
    }

    // ── Non-generic version for responses with no data ────────
    // e.g. delete operations
    public class ApiResponse
    {
        public bool Success { get; set; }
        public string Message { get; set; } = string.Empty;
        public List<string> Errors { get; set; } = new();

        public static ApiResponse SuccessResponse(string message = "Operation successful.")
        {
            return new ApiResponse
            {
                Success = true,
                Message = message,
                Errors = new List<string>()
            };
        }

        public static ApiResponse FailureResponse(string message, List<string>? errors = null)
        {
            return new ApiResponse
            {
                Success = false,
                Message = message,
                Errors = errors ?? new List<string>()
            };
        }
    }
}
