﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PayXpert.Application.DTOs.Tax
{

    // ── Request DTOs ──────────────────────────────────────────

    public class CalculateTaxRequestDto
    {
        public string EmployeeID { get; set; } = string.Empty;
        public int TaxYear { get; set; }
    }

    // ── Response DTOs ─────────────────────────────────────────

    public class TaxResponseDto
    {
        public string TaxID { get; set; } = string.Empty;
        public string EmployeeID { get; set; } = string.Empty;
        public string EmployeeFullName { get; set; } = string.Empty;
        public int TaxYear { get; set; }
        public decimal TaxableIncome { get; set; }
        public decimal TaxAmount { get; set; }
        public decimal EffectiveTaxRate =>
            TaxableIncome > 0
            ? Math.Round((TaxAmount / TaxableIncome) * 100, 2)
            : 0;
        public DateTime CreatedAt { get; set; }
        public string CreatedBy { get; set; } = string.Empty;
    }

    public class TaxSummaryDto
    {
        public string TaxID { get; set; } = string.Empty;
        public string EmployeeID { get; set; } = string.Empty;
        public string EmployeeFullName { get; set; } = string.Empty;
        public int TaxYear { get; set; }
        public decimal TaxAmount { get; set; }
    }
}
