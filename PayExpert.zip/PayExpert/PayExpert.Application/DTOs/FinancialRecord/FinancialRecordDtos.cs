﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PayXpert.Application.DTOs.FinancialRecord
{
    // ── Request DTOs ──────────────────────────────────────────

    public class AddFinancialRecordRequestDto
    {
        public string EmployeeID { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public string RecordType { get; set; } = string.Empty;
    }

    // ── Response DTOs ─────────────────────────────────────────

    public class FinancialRecordResponseDto
    {
        public string RecordID { get; set; } = string.Empty;
        public string EmployeeID { get; set; } = string.Empty;
        public string EmployeeFullName { get; set; } = string.Empty;
        public DateTime RecordDate { get; set; }
        public string Description { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public string RecordType { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }
        public string CreatedBy { get; set; } = string.Empty;
    }

    public class FinancialRecordSummaryDto
    {
        public string RecordID { get; set; } = string.Empty;
        public string EmployeeID { get; set; } = string.Empty;
        public DateTime RecordDate { get; set; }
        public string RecordType { get; set; } = string.Empty;
        public decimal Amount { get; set; }
    }
}
