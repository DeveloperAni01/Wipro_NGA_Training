﻿using FluentValidation;
using PayXpert.Application.DTOs.Employee;
using PayXpert.Application.DTOs.Payroll;
using PayXpert.Application.DTOs.Tax;
using PayXpert.Application.DTOs.FinancialRecord;

namespace PayXpert.Application.Validators
{
    // ── Employee Validators ───────────────────────────────────

    public class CreateEmployeeValidator : AbstractValidator<CreateEmployeeRequestDto>
    {
        public CreateEmployeeValidator()
        {
            RuleFor(x => x.FirstName)
                .NotEmpty().WithMessage("First name is required.")
                .MaximumLength(100).WithMessage("First name cannot exceed 100 characters.")
                .Matches(@"^[a-zA-Z\s]+$").WithMessage("First name can only contain letters.");

            RuleFor(x => x.LastName)
                .NotEmpty().WithMessage("Last name is required.")
                .MaximumLength(100).WithMessage("Last name cannot exceed 100 characters.")
                .Matches(@"^[a-zA-Z\s]+$").WithMessage("Last name can only contain letters.");

            RuleFor(x => x.DateOfBirth)
                .NotEmpty().WithMessage("Date of birth is required.")
                .LessThan(DateTime.Today.AddYears(-18))
                .WithMessage("Employee must be at least 18 years old.")
                .GreaterThan(DateTime.Today.AddYears(-100))
                .WithMessage("Please enter a valid date of birth.");

            RuleFor(x => x.Gender)
                .NotEmpty().WithMessage("Gender is required.")
                .Must(g => new[] { "Male", "Female", "Other" }.Contains(g))
                .WithMessage("Gender must be Male, Female, or Other.");

            RuleFor(x => x.Email)
                .NotEmpty().WithMessage("Email is required.")
                .EmailAddress().WithMessage("Please enter a valid email address.")
                .MaximumLength(150).WithMessage("Email cannot exceed 150 characters.");

            RuleFor(x => x.PhoneNumber)
                .NotEmpty().WithMessage("Phone number is required.")
                .Matches(@"^\+?[0-9]{7,15}$")
                .WithMessage("Please enter a valid phone number.");

            RuleFor(x => x.Address)
                .NotEmpty().WithMessage("Address is required.")
                .MaximumLength(300).WithMessage("Address cannot exceed 300 characters.");

            RuleFor(x => x.Position)
                .NotEmpty().WithMessage("Position is required.")
                .MaximumLength(100).WithMessage("Position cannot exceed 100 characters.");

            RuleFor(x => x.JoiningDate)
                .NotEmpty().WithMessage("Joining date is required.")
                .LessThanOrEqualTo(DateTime.Today)
                .WithMessage("Joining date cannot be in the future.");
        }
    }

    public class UpdateEmployeeValidator : AbstractValidator<UpdateEmployeeRequestDto>
    {
        public UpdateEmployeeValidator()
        {
            RuleFor(x => x.EmployeeID)
                .NotEmpty().WithMessage("Employee ID is required.");

            RuleFor(x => x.FirstName)
                .NotEmpty().WithMessage("First name is required.")
                .MaximumLength(100).WithMessage("First name cannot exceed 100 characters.")
                .Matches(@"^[a-zA-Z\s]+$").WithMessage("First name can only contain letters.");

            RuleFor(x => x.LastName)
                .NotEmpty().WithMessage("Last name is required.")
                .MaximumLength(100).WithMessage("Last name cannot exceed 100 characters.")
                .Matches(@"^[a-zA-Z\s]+$").WithMessage("Last name can only contain letters.");

            RuleFor(x => x.Email)
                .NotEmpty().WithMessage("Email is required.")
                .EmailAddress().WithMessage("Please enter a valid email address.")
                .MaximumLength(150).WithMessage("Email cannot exceed 150 characters.");

            RuleFor(x => x.PhoneNumber)
                .NotEmpty().WithMessage("Phone number is required.")
                .Matches(@"^\+?[0-9]{7,15}$")
                .WithMessage("Please enter a valid phone number.");

            RuleFor(x => x.Address)
                .NotEmpty().WithMessage("Address is required.")
                .MaximumLength(300).WithMessage("Address cannot exceed 300 characters.");

            RuleFor(x => x.Position)
                .NotEmpty().WithMessage("Position is required.")
                .MaximumLength(100).WithMessage("Position cannot exceed 100 characters.");
        }
    }

    // ── Payroll Validators ────────────────────────────────────

    public class GeneratePayrollValidator : AbstractValidator<GeneratePayrollRequestDto>
    {
        public GeneratePayrollValidator()
        {
            RuleFor(x => x.EmployeeID)
                .NotEmpty().WithMessage("Employee ID is required.");

            RuleFor(x => x.PayPeriodStartDate)
                .NotEmpty().WithMessage("Pay period start date is required.");

            RuleFor(x => x.PayPeriodEndDate)
                .NotEmpty().WithMessage("Pay period end date is required.")
                .GreaterThan(x => x.PayPeriodStartDate)
                .WithMessage("Pay period end date must be after start date.");

            RuleFor(x => x.BasicSalary)
                .GreaterThan(0).WithMessage("Basic salary must be greater than zero.");

            RuleFor(x => x.OvertimePay)
                .GreaterThanOrEqualTo(0).WithMessage("Overtime pay cannot be negative.");

            RuleFor(x => x.Deductions)
                .GreaterThanOrEqualTo(0).WithMessage("Deductions cannot be negative.")
                .Must((dto, deductions) => deductions < dto.BasicSalary + dto.OvertimePay)
                .WithMessage("Deductions cannot exceed gross salary.");
        }
    }

    // ── Tax Validators ────────────────────────────────────────

    public class CalculateTaxValidator : AbstractValidator<CalculateTaxRequestDto>
    {
        public CalculateTaxValidator()
        {
            RuleFor(x => x.EmployeeID)
                .NotEmpty().WithMessage("Employee ID is required.");

            RuleFor(x => x.TaxYear)
                .NotEmpty().WithMessage("Tax year is required.")
                .InclusiveBetween(2000, DateTime.Today.Year)
                .WithMessage($"Tax year must be between 2000 and {DateTime.Today.Year}.");
        }
    }

    // ── Financial Record Validators ───────────────────────────

    public class AddFinancialRecordValidator : AbstractValidator<AddFinancialRecordRequestDto>
    {
        public AddFinancialRecordValidator()
        {
            RuleFor(x => x.EmployeeID)
                .NotEmpty().WithMessage("Employee ID is required.");

            RuleFor(x => x.Description)
                .NotEmpty().WithMessage("Description is required.")
                .MaximumLength(300).WithMessage("Description cannot exceed 300 characters.");

            RuleFor(x => x.Amount)
                .GreaterThan(0).WithMessage("Amount must be greater than zero.");

            RuleFor(x => x.RecordType)
                .NotEmpty().WithMessage("Record type is required.")
                .Must(t => new[] { "Income", "Expense", "TaxPayment", "Bonus", "Deduction" }.Contains(t))
                .WithMessage("Record type must be one of: Income, Expense, TaxPayment, Bonus, Deduction.");
        }
    }
}