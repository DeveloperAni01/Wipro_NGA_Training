﻿using PayXpert.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace PayXpert.Application.Interfaces
{
    public interface IPayrollService
    {
        Task<Payroll> GeneratePayrollAsync(string employeeId,
    DateTime startDate,
    DateTime endDate,
    decimal basicSalary,  
    decimal overtimePay,
    decimal deductions);
        Task<Payroll> GetPayrollByIdAsync(string payrollId);
        Task<ICollection<Payroll>> GetPayrollsForEmployeeAsync(string employeeId);
        Task<ICollection<Payroll>> GetPayrollsForPeriodAsync(DateTime startDate, DateTime endDate);
    }
}
