﻿using PayXpert.Domain.Entities;


namespace PayXpert.Application.Interfaces
{
    public interface IEmployeeService
    {
        Task<Employee> GetEmployeeByIdAsync(string employeeId);
        Task<ICollection<Employee>> GetAllEmployeesAsync();
        Task<Employee> AddEmployeeAsync(Employee employee);
        Task<Employee> UpdateEmployeeAsync(Employee employee);
        Task<bool> SoftDeleteEmployeeAsync(string employeeId, string deletedBy);
        Task<bool> HardDeleteEmployeeAsync(string employeeId);
    }
}
