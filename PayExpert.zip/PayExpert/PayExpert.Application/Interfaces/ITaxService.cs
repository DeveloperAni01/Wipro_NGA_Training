﻿using PayXpert.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace PayXpert.Application.Interfaces
{
    public interface ITaxService
    {
        Task<Tax> CalculateTaxAsync(string employeeId, int taxYear);
        Task<Tax> GetTaxByIdAsync(string taxId);
        Task<ICollection<Tax>> GetTaxesForEmployeeAsync(string employeeId);
        Task<ICollection<Tax>> GetTaxesForYearAsync(int taxYear);
    }
}
