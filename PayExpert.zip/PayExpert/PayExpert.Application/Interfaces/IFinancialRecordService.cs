﻿using PayXpert.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace PayXpert.Application.Interfaces
{
    public interface IFinancialRecordService
    {
        Task<FinancialRecord> AddFinancialRecordAsync(string employeeId, string description, decimal amount, string recordType, string createdBy);
        Task<FinancialRecord> GetFinancialRecordByIdAsync(string recordId);
        Task<ICollection<FinancialRecord>> GetFinancialRecordsForEmployeeAsync(string employeeId);
        Task<ICollection<FinancialRecord>> GetFinancialRecordsForDateAsync(DateTime recordDate);
    }
}
