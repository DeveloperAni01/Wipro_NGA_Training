﻿namespace PayXpert.Infrastructure.Exceptions
{
    // ── 1. Employee Not Found ─────────────────────────────────
    public class EmployeeNotFoundException : Exception
    {
        public EmployeeNotFoundException()
            : base("Employee not found.") { }

        public EmployeeNotFoundException(string employeeId)
            : base($"Employee with ID '{employeeId}' was not found.") { }

        public EmployeeNotFoundException(string message, Exception innerException)
            : base(message, innerException) { }
    }

    // ── 2. Payroll Generation Error ───────────────────────────
    public class PayrollGenerationException : Exception
    {
        public PayrollGenerationException()
            : base("An error occurred while generating payroll.") { }

        public PayrollGenerationException(string message)
            : base(message) { }

        public PayrollGenerationException(string message, Exception innerException)
            : base(message, innerException) { }
    }

    // ── 3. Tax Calculation Error ──────────────────────────────
    public class TaxCalculationException : Exception
    {
        public TaxCalculationException()
            : base("An error occurred while calculating tax.") { }

        public TaxCalculationException(string message)
            : base(message) { }

        public TaxCalculationException(string message, Exception innerException)
            : base(message, innerException) { }
    }

    // ── 4. Financial Record Error ─────────────────────────────
    public class FinancialRecordException : Exception
    {
        public FinancialRecordException()
            : base("An error occurred while managing financial records.") { }

        public FinancialRecordException(string message)
            : base(message) { }

        public FinancialRecordException(string message, Exception innerException)
            : base(message, innerException) { }
    }

    // ── 5. Invalid Input ──────────────────────────────────────
    public class InvalidInputException : Exception
    {
        public InvalidInputException()
            : base("The provided input is invalid.") { }

        public InvalidInputException(string message)
            : base(message) { }

        public InvalidInputException(string message, Exception innerException)
            : base(message, innerException) { }
    }

    // ── 6. Database Connection Error ──────────────────────────
    public class DatabaseConnectionException : Exception
    {
        public DatabaseConnectionException()
            : base("Unable to establish a connection to the database.") { }

        public DatabaseConnectionException(string message)
            : base(message) { }

        public DatabaseConnectionException(string message, Exception innerException)
            : base(message, innerException) { }
    }
}