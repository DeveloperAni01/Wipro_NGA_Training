﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;
using PayXpert.Application.Interfaces;
using PayXpert.Domain.Entities;
using PayXpert.Infrastructure.Data;
using PayXpert.Infrastructure.Exceptions;

namespace PayXpert.Application.Services
{
    public class TaxService : ITaxService
    {
        private readonly ApplicationDbContext _context;

        public TaxService(ApplicationDbContext context)
        {
            _context = context;
        }

        // ── Calculate Tax ─────────────────────────────────────
        public async Task<Tax> CalculateTaxAsync(string employeeId, int taxYear)
        {
            // Validate employee exists
            var employee = await _context.Employees
                .FirstOrDefaultAsync(e => e.EmployeeID == employeeId && e.IsActive);

            if (employee == null)
                throw new EmployeeNotFoundException(employeeId);

            // Check if tax record already exists for this year
            var existingTax = await _context.Taxes
                .FirstOrDefaultAsync(t => t.EmployeeID == employeeId
                                       && t.TaxYear == taxYear);

            if (existingTax != null)
                throw new TaxCalculationException($"Tax record for employee '{employeeId}' for year {taxYear} already exists.");

            // Calculate taxable income from payrolls in that tax year
            var annualPayrolls = await _context.Payrolls
                .Where(p => p.EmployeeID == employeeId
                         && p.PayPeriodStartDate.Year == taxYear)
                .ToListAsync();

            if (!annualPayrolls.Any())
                throw new TaxCalculationException($"No payroll records found for employee '{employeeId}' in {taxYear}.");

            var taxableIncome = annualPayrolls.Sum(p => p.NetSalary);

            // ── Tax Slab Calculation (example slabs) ──────────
            // You can adjust these slabs as per your requirements
            decimal taxAmount = CalculateTaxAmount(taxableIncome);

            var tax = new Tax
            {
                TaxID = await GenerateTaxIdAsync(),
                EmployeeID = employeeId,
                TaxYear = taxYear,
                TaxableIncome = taxableIncome,
                TaxAmount = taxAmount,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            _context.Taxes.Add(tax);
            await _context.SaveChangesAsync();
            tax.Employee = employee;

            return tax;
        }

        // ── Get Tax By ID ─────────────────────────────────────
        public async Task<Tax> GetTaxByIdAsync(string taxId)
        {
            var tax = await _context.Taxes
                .Include(t => t.Employee)
                .FirstOrDefaultAsync(t => t.TaxID == taxId);

            if (tax == null)
                throw new TaxCalculationException($"Tax record with ID '{taxId}' was not found.");
            

            return tax;
        }

        // ── Get Taxes For Employee ────────────────────────────
        public async Task<ICollection<Tax>> GetTaxesForEmployeeAsync(string employeeId)
        {
            var employeeExists = await _context.Employees
                .AnyAsync(e => e.EmployeeID == employeeId);

            if (!employeeExists)
                throw new EmployeeNotFoundException(employeeId);

            return await _context.Taxes
                .Where(t => t.EmployeeID == employeeId)
                .Include(t => t.Employee)
                .OrderByDescending(t => t.TaxYear)
                .ToListAsync();
        }

        // ── Get Taxes For Year ────────────────────────────────
        public async Task<ICollection<Tax>> GetTaxesForYearAsync(int taxYear)
        {
            return await _context.Taxes
                .Include(t => t.Employee)
                .Where(t => t.TaxYear == taxYear)
                .OrderBy(t => t.EmployeeID)
                .ToListAsync();
        }

        // ── Private: Tax Slab Calculation ─────────────────────
        private static decimal CalculateTaxAmount(decimal taxableIncome)
        {
            // Example progressive tax slabs
            // Adjust these based on actual tax rules required
            return taxableIncome switch
            {
                <= 250000 => 0,
                <= 500000 => (taxableIncome - 250000) * 0.05m,
                <= 1000000 => 12500 + (taxableIncome - 500000) * 0.20m,
                _ => 112500 + (taxableIncome - 1000000) * 0.30m
            };
        }

        // ── Private: Generate Custom Tax ID ───────────────────
        private async Task<string> GenerateTaxIdAsync()
        {
            var yearMonth = DateTime.UtcNow.ToString("yyyyMM");
            var prefix = $"PX-TAX-{yearMonth}-";

            var lastTax = await _context.Taxes
                .Where(t => t.TaxID.StartsWith(prefix))
                .OrderByDescending(t => t.TaxID)
                .FirstOrDefaultAsync();

            if (lastTax == null)
                return $"{prefix}001";

            var parts = lastTax.TaxID.Split('-');
            if (parts.Length == 4 && int.TryParse(parts[3], out int lastSeq))
                return $"{prefix}{(lastSeq + 1):D3}";

            return $"{prefix}001";
        }

    }
}