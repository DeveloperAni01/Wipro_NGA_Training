﻿using Microsoft.EntityFrameworkCore;
using PayXpert.Application.Interfaces;
using PayXpert.Domain.Entities;
using PayXpert.Infrastructure.Data;
using PayXpert.Infrastructure.Exceptions;

namespace PayXpert.Infrastructure.Services
{
    public class PayrollService : IPayrollService
    {
        private readonly ApplicationDbContext _context;

        public PayrollService(ApplicationDbContext context)
        {
            _context = context;
        }

        // ── Generate Payroll ──────────────────────────────────
        public async Task<Payroll> GeneratePayrollAsync(string employeeId, DateTime startDate, DateTime endDate, decimal basicSalary, decimal overtimePay, decimal deductions)
        {
            // Validate employee exists and is active
            var employee = await _context.Employees
                .FirstOrDefaultAsync(e => e.EmployeeID == employeeId && e.IsActive);

            if (employee == null)
                throw new EmployeeNotFoundException(employeeId);

            // Validate date range
            if (startDate >= endDate)
                throw new PayrollGenerationException("Pay period start date must be before end date.");

            // Check for overlapping payroll for same employee
            var overlapping = await _context.Payrolls
                .AnyAsync(p => p.EmployeeID == employeeId
                            && p.PayPeriodStartDate < endDate
                            && p.PayPeriodEndDate > startDate);

            if (overlapping)
                throw new PayrollGenerationException(
                    $"A payroll record already exists for employee '{employeeId}' in this period.");

            // Validate salary values
            if (basicSalary <= 0)
                throw new PayrollGenerationException("Basic salary must be greater than zero.");

            if (overtimePay < 0)
                throw new PayrollGenerationException("Overtime pay cannot be negative.");

            if (deductions < 0)
                throw new PayrollGenerationException("Deductions cannot be negative.");

            if (deductions >= basicSalary + overtimePay)
                throw new PayrollGenerationException("Deductions cannot exceed gross salary.");

            // Calculate net salary
            var netSalary = basicSalary + overtimePay - deductions;

            var payroll = new Payroll
            {
                PayrollID = await GeneratePayrollIdAsync(),
                EmployeeID = employeeId,
                PayPeriodStartDate = startDate,
                PayPeriodEndDate = endDate,
                BasicSalary = basicSalary,
                OvertimePay = overtimePay,
                Deductions = deductions,
                NetSalary = netSalary,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow,
                CreatedBy = "System"
            };

            _context.Payrolls.Add(payroll);
            await _context.SaveChangesAsync();

            // Attach employee navigation property
            payroll.Employee = employee;

            return payroll;
        }


        // ── Get Payroll By ID ─────────────────────────────────
        public async Task<Payroll> GetPayrollByIdAsync(string payrollId)
        {
            var payroll = await _context.Payrolls
                .Include(p => p.Employee)
                .FirstOrDefaultAsync(p => p.PayrollID == payrollId);

            if (payroll == null)
                throw new PayrollGenerationException(
                    $"Payroll record with ID '{payrollId}' was not found.");

            return payroll;
        }

        // ── Get Payrolls For Employee ─────────────────────────
        public async Task<ICollection<Payroll>> GetPayrollsForEmployeeAsync(string employeeId)
        {
            var employeeExists = await _context.Employees
                .AnyAsync(e => e.EmployeeID == employeeId);

            if (!employeeExists)
                throw new EmployeeNotFoundException(employeeId);

            return await _context.Payrolls
                .Where(p => p.EmployeeID == employeeId)
                .OrderByDescending(p => p.PayPeriodStartDate)
                .ToListAsync();
        }

        // ── Get Payrolls For Period ───────────────────────────
        public async Task<ICollection<Payroll>> GetPayrollsForPeriodAsync(
            DateTime startDate,
            DateTime endDate)
        {
            if (startDate >= endDate)
                throw new PayrollGenerationException("Start date must be before end date.");

            return await _context.Payrolls
                .Include(p => p.Employee)
                .Where(p => p.PayPeriodStartDate >= startDate
                         && p.PayPeriodEndDate <= endDate)
                .OrderByDescending(p => p.PayPeriodStartDate)
                .ToListAsync();
        }

        // ── Private: Generate Custom Payroll ID ───────────────
        private async Task<string> GeneratePayrollIdAsync()
        {
            var yearMonth = DateTime.UtcNow.ToString("yyyyMM");
            var prefix = $"PX-PAY-{yearMonth}-";

            var lastPayroll = await _context.Payrolls
                .Where(p => p.PayrollID.StartsWith(prefix))
                .OrderByDescending(p => p.PayrollID)
                .FirstOrDefaultAsync();

            if (lastPayroll == null)
                return $"{prefix}001";

            var parts = lastPayroll.PayrollID.Split('-');
            if (parts.Length == 4 && int.TryParse(parts[3], out int lastSeq))
                return $"{prefix}{(lastSeq + 1):D3}";

            return $"{prefix}001";
        }
    }
}