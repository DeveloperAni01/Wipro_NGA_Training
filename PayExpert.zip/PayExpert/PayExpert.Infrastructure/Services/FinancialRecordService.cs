﻿using Microsoft.EntityFrameworkCore;
using PayXpert.Application.Interfaces;
using PayXpert.Domain.Entities;
using PayXpert.Infrastructure.Data;
using PayXpert.Infrastructure.Exceptions;

namespace PayXpert.Application.Services
{
    public class FinancialRecordService : IFinancialRecordService
    {
        private readonly ApplicationDbContext _context;

        public FinancialRecordService(ApplicationDbContext context)
        {
            _context = context;
        }

        // ── Add Financial Record ──────────────────────────────
        public async Task<FinancialRecord> AddFinancialRecordAsync(
            string employeeId,
            string description,
            decimal amount,
            string recordType,
            string createdBy)
        {
            // Validate employee exists
            var employeeExists = await _context.Employees
                .AnyAsync(e => e.EmployeeID == employeeId && e.IsActive);

            if (!employeeExists)
                throw new EmployeeNotFoundException(employeeId);

            // Validate amount
            if (amount <= 0)
                throw new FinancialRecordException("Amount must be greater than zero.");

            // Validate record type
            var validTypes = new[] { "Income", "Expense", "TaxPayment", "Bonus", "Deduction" };
            if (!validTypes.Contains(recordType))
                throw new FinancialRecordException($"Invalid record type '{recordType}'. Valid types: {string.Join(", ", validTypes)}");

            var record = new FinancialRecord
            {
                RecordID = await GenerateRecordIdAsync(),
                EmployeeID = employeeId,
                RecordDate = DateTime.UtcNow,
                Description = description,
                Amount = amount,
                RecordType = recordType,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow,
                CreatedBy = createdBy
            };

            _context.FinancialRecords.Add(record);
            await _context.SaveChangesAsync();

            return record;
        }

        // ── Get Financial Record By ID ────────────────────────
        public async Task<FinancialRecord> GetFinancialRecordByIdAsync(string recordId)
        {
            var record = await _context.FinancialRecords
                .Include(f => f.Employee)
                .FirstOrDefaultAsync(f => f.RecordID == recordId);

            if (record == null)
                throw new FinancialRecordException($"Financial record with ID '{recordId}' was not found.");

            return record;
        }

        // ── Get Financial Records For Employee ────────────────
        public async Task<ICollection<FinancialRecord>> GetFinancialRecordsForEmployeeAsync(string employeeId)
        {
            var employeeExists = await _context.Employees
                .AnyAsync(e => e.EmployeeID == employeeId);

            if (!employeeExists)
                throw new EmployeeNotFoundException(employeeId);

            return await _context.FinancialRecords
                .Where(f => f.EmployeeID == employeeId)
                .OrderByDescending(f => f.RecordDate)
                .ToListAsync();
        }

        // ── Get Financial Records For Date ────────────────────
        public async Task<ICollection<FinancialRecord>> GetFinancialRecordsForDateAsync(DateTime recordDate)
        {
            return await _context.FinancialRecords
                .Include(f => f.Employee)
                .Where(f => f.RecordDate.Date == recordDate.Date)
                .OrderBy(f => f.EmployeeID)
                .ToListAsync();
        }

        // ── Private: Generate Custom Record ID ────────────────
        private async Task<string> GenerateRecordIdAsync()
        {
            var yearMonth = DateTime.UtcNow.ToString("yyyyMM");
            var prefix = $"PX-FR-{yearMonth}-";

            var lastRecord = await _context.FinancialRecords
                .Where(f => f.RecordID.StartsWith(prefix))
                .OrderByDescending(f => f.RecordID)
                .FirstOrDefaultAsync();

            if (lastRecord == null)
                return $"{prefix}001";

            var parts = lastRecord.RecordID.Split('-');
            if (parts.Length == 4 && int.TryParse(parts[3], out int lastSeq))
                return $"{prefix}{(lastSeq + 1):D3}";

            return $"{prefix}001";
        }
    }
}