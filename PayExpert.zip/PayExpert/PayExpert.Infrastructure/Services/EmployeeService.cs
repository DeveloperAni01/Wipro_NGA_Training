﻿using Microsoft.EntityFrameworkCore;
using PayXpert.Application.Interfaces;
using PayXpert.Domain.Entities;
using PayXpert.Infrastructure.Data;
using PayXpert.Infrastructure.Exceptions;

namespace PayXpert.Infrastructure.Services
{
    public class EmployeeService : IEmployeeService
    {
        private readonly ApplicationDbContext _context;

        public EmployeeService(ApplicationDbContext context)
        {
            _context = context;
        }

        // ── Get Employee By ID ────────────────────────────────
        public async Task<Employee> GetEmployeeByIdAsync(string employeeId)
        {
            var employee = await _context.Employees
                .FirstOrDefaultAsync(e => e.EmployeeID == employeeId);

            if (employee == null)
                throw new EmployeeNotFoundException(employeeId);

            return employee;
        }

        // ── Get All Employees ─────────────────────────────────
        public async Task<ICollection<Employee>> GetAllEmployeesAsync()
        {
            return await _context.Employees
                .Where(e => e.IsActive)
                .OrderBy(e => e.FirstName)
                .ToListAsync();
        }

        // ── Add Employee ──────────────────────────────────────
        public async Task<Employee> AddEmployeeAsync(Employee employee)
        {
            // Check if email already exists
            var emailExists = await _context.Employees
                .AnyAsync(e => e.Email == employee.Email);

            if (emailExists)
                throw new InvalidInputException($"An employee with email '{employee.Email}' already exists.");

            // Generate custom ID
            employee.EmployeeID = await GenerateEmployeeIdAsync();
            employee.CreatedAt = DateTime.UtcNow;
            employee.UpdatedAt = DateTime.UtcNow;
            employee.IsActive = true;

            _context.Employees.Add(employee);
            await _context.SaveChangesAsync();

            return employee;
        }

        // ── Update Employee ───────────────────────────────────
        public async Task<Employee> UpdateEmployeeAsync(Employee employee)
        {
            var existing = await _context.Employees
                .FirstOrDefaultAsync(e => e.EmployeeID == employee.EmployeeID);

            if (existing == null)
                throw new EmployeeNotFoundException(employee.EmployeeID);

            // Check email uniqueness (excluding current employee)
            var emailExists = await _context.Employees
                .AnyAsync(e => e.Email == employee.Email
                            && e.EmployeeID != employee.EmployeeID);

            if (emailExists)
                throw new InvalidInputException($"Email '{employee.Email}' is already in use by another employee.");

            // Update only allowed fields
            existing.FirstName = employee.FirstName;
            existing.LastName = employee.LastName;
            existing.Gender = employee.Gender;
            existing.Email = employee.Email;
            existing.PhoneNumber = employee.PhoneNumber;
            existing.Address = employee.Address;
            existing.Position = employee.Position;
            existing.UpdatedAt = DateTime.UtcNow;

            await _context.SaveChangesAsync();

            return existing;
        }

        // ── Soft Delete Employee ──────────────────────────────
        public async Task<bool> SoftDeleteEmployeeAsync(string employeeId, string deletedBy)
        {
            var employee = await _context.Employees
                .FirstOrDefaultAsync(e => e.EmployeeID == employeeId);

            if (employee == null)
                throw new EmployeeNotFoundException(employeeId);

            employee.IsActive = false;
            employee.TerminationDate = DateTime.UtcNow;
            employee.UpdatedAt = DateTime.UtcNow;

            await _context.SaveChangesAsync();

            return true;
        }

        // ── Hard Delete Employee ──────────────────────────────
        public async Task<bool> HardDeleteEmployeeAsync(string employeeId)
        {
            var employee = await _context.Employees
                .FirstOrDefaultAsync(e => e.EmployeeID == employeeId);

            if (employee == null)
                throw new EmployeeNotFoundException(employeeId);

            // Cascade delete will automatically remove
            // all related Payroll, Tax, FinancialRecord rows
            _context.Employees.Remove(employee);
            await _context.SaveChangesAsync();

            return true;
        }

        // ── Private: Generate Custom Employee ID ──────────────
        private async Task<string> GenerateEmployeeIdAsync()
        {
            var yearMonth = DateTime.UtcNow.ToString("yyyyMM"); // e.g. 202501
            var prefix = $"PX-EMP-{yearMonth}-";

            // Find last employee ID with same year-month prefix
            var lastEmployee = await _context.Employees
                .Where(e => e.EmployeeID.StartsWith(prefix))
                .OrderByDescending(e => e.EmployeeID)
                .FirstOrDefaultAsync();

            if (lastEmployee == null)
                return $"{prefix}001";

            // Extract sequence number and increment
            var parts = lastEmployee.EmployeeID.Split('-');
            if (parts.Length == 4 && int.TryParse(parts[3], out int lastSeq))
                return $"{prefix}{(lastSeq + 1):D3}";

            return $"{prefix}001";
        }



    }
}