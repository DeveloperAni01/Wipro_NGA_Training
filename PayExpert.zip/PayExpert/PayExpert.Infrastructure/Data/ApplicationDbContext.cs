﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using PayXpert.Domain.Entities;
using PayXpert.Infrastructure.Identity;

namespace PayXpert.Infrastructure.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        // ── DbSets (Business Tables) ──────────────────────────
        public DbSet<Employee> Employees => Set<Employee>();
        public DbSet<Payroll> Payrolls => Set<Payroll>();
        public DbSet<Tax> Taxes => Set<Tax>();
        public DbSet<FinancialRecord> FinancialRecords => Set<FinancialRecord>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Always call base first — sets up Identity tables
            base.OnModelCreating(modelBuilder);

            // ── Employee Configuration ────────────────────────
            modelBuilder.Entity<Employee>(entity =>
            {
                entity.HasKey(e => e.EmployeeID);

                entity.Property(e => e.EmployeeID)
                      .HasMaxLength(50)
                      .IsRequired();

                entity.Property(e => e.FirstName)
                      .HasMaxLength(100)
                      .IsRequired();

                entity.Property(e => e.LastName)
                      .HasMaxLength(100)
                      .IsRequired();

                entity.Property(e => e.Gender)
                      .HasMaxLength(20)
                      .IsRequired();

                entity.Property(e => e.Email)
                      .HasMaxLength(150)
                      .IsRequired();

                // Unique constraint on Email
                entity.HasIndex(e => e.Email)
                      .IsUnique();

                entity.Property(e => e.PhoneNumber)
                      .HasMaxLength(10)
                      .IsRequired();

                entity.Property(e => e.Address)
                      .HasMaxLength(300)
                      .IsRequired();

                entity.Property(e => e.Position)
                      .HasMaxLength(100)
                      .IsRequired();

                entity.Property(e => e.TerminationDate)
                      .IsRequired(false);

                entity.Property(e => e.IsActive)
                      .HasDefaultValue(true);

                entity.Property(e => e.CreatedBy)
                      .HasMaxLength(100)
                      .IsRequired();
            });

            // ── Payroll Configuration ─────────────────────────
            modelBuilder.Entity<Payroll>(entity =>
            {
                entity.HasKey(p => p.PayrollID);

                entity.Property(p => p.PayrollID)
                      .HasMaxLength(50)
                      .IsRequired();

                entity.Property(p => p.BasicSalary)
                      .HasColumnType("decimal(18,2)")
                      .IsRequired();

                entity.Property(p => p.OvertimePay)
                      .HasColumnType("decimal(18,2)")
                      .IsRequired();

                entity.Property(p => p.Deductions)
                      .HasColumnType("decimal(18,2)")
                      .IsRequired();

                entity.Property(p => p.NetSalary)
                      .HasColumnType("decimal(18,2)")
                      .IsRequired();

                entity.Property(p => p.CreatedBy)
                      .HasMaxLength(100)
                      .IsRequired();

                // Relationship: Employee → Payroll (CASCADE DELETE)
                entity.HasOne(p => p.Employee)
                      .WithMany(e => e.Payrolls)
                      .HasForeignKey(p => p.EmployeeID)
                      .OnDelete(DeleteBehavior.Cascade);
            });

            // ── Tax Configuration ─────────────────────────────
            modelBuilder.Entity<Tax>(entity =>
            {
                entity.HasKey(t => t.TaxID);

                entity.Property(t => t.TaxID)
                      .HasMaxLength(50)
                      .IsRequired();

                entity.Property(t => t.TaxableIncome)
                      .HasColumnType("decimal(18,2)")
                      .IsRequired();

                entity.Property(t => t.TaxAmount)
                      .HasColumnType("decimal(18,2)")
                      .IsRequired();

                entity.Property(t => t.CreatedBy)
                      .HasMaxLength(100)
                      .IsRequired();

                // Unique constraint: one tax record per employee per year
                entity.HasIndex(t => new { t.EmployeeID, t.TaxYear })
                      .IsUnique();

                // Relationship: Employee → Tax (CASCADE DELETE)
                entity.HasOne(t => t.Employee)
                      .WithMany(e => e.Taxes)
                      .HasForeignKey(t => t.EmployeeID)
                      .OnDelete(DeleteBehavior.Cascade);
            });

            // ── FinancialRecord Configuration ─────────────────
            modelBuilder.Entity<FinancialRecord>(entity =>
            {
                entity.HasKey(f => f.RecordID);

                entity.Property(f => f.RecordID)
                      .HasMaxLength(50)
                      .IsRequired();

                entity.Property(f => f.Description)
                      .HasMaxLength(300)
                      .IsRequired();

                entity.Property(f => f.Amount)
                      .HasColumnType("decimal(18,2)")
                      .IsRequired();

                entity.Property(f => f.RecordType)
                      .HasMaxLength(50)
                      .IsRequired();

                entity.Property(f => f.CreatedBy)
                      .HasMaxLength(100)
                      .IsRequired();

                // Relationship: Employee → FinancialRecord (CASCADE DELETE)
                entity.HasOne(f => f.Employee)
                      .WithMany(e => e.FinancialRecords)
                      .HasForeignKey(f => f.EmployeeID)
                      .OnDelete(DeleteBehavior.Cascade);
            });
        }
    }
}