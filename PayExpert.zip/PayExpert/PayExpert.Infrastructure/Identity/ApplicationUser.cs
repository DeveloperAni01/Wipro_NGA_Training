﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Text;

namespace PayXpert.Infrastructure.Identity
{
    public class ApplicationUser : IdentityUser
    {
        // ── Link to Employee ──────────────────────────────────
        // Not every user is an employee (e.g. SuperAdmin)
        // so this is nullable
        public string? EmployeeID { get; set; }

        // ── Audit Fields ──────────────────────────────────────
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
        public bool IsActive { get; set; } = true;
    }
}
