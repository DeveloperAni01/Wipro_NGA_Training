﻿using Moq;
using NUnit.Framework;
using FluentAssertions;
using PayXpert.Application.Interfaces;
using PayXpert.Domain.Entities;
using PayXpert.Infrastructure.Exceptions;

namespace PayXpert.Tests.UnitTests
{
    [TestFixture]
    public class PayrollServiceTests
    {
        private Mock<IPayrollService> _payrollServiceMock;
        private Mock<IEmployeeService> _employeeServiceMock;
        private Mock<ITaxService> _taxServiceMock;

        [SetUp]
        public void Setup()
        {
            _payrollServiceMock = new Mock<IPayrollService>();
            _employeeServiceMock = new Mock<IEmployeeService>();
            _taxServiceMock = new Mock<ITaxService>();
        }

        // ════════════════════════════════════════════════════════
        // TEST 1 — CalculateGrossSalaryForEmployee
        // Objective: Verify gross salary = BasicSalary + OvertimePay
        // ════════════════════════════════════════════════════════

        [Test]
        public async Task CalculateGrossSalaryForEmployee_ShouldReturnCorrectGrossSalary()
        {
            // ── Arrange ───────────────────────────────────────
            var employeeId = "PX-EMP-202501-001";
            var startDate = new DateTime(2025, 1, 1);
            var endDate = new DateTime(2025, 1, 31);
            decimal basicSalary = 50000;
            decimal overtimePay = 10000;
            decimal deductions = 5000;
            decimal expectedGross = basicSalary + overtimePay; // 60000

            var mockPayroll = new Payroll
            {
                PayrollID = "PX-PAY-202501-001",
                EmployeeID = employeeId,
                PayPeriodStartDate = startDate,
                PayPeriodEndDate = endDate,
                BasicSalary = basicSalary,
                OvertimePay = overtimePay,
                Deductions = deductions,
                NetSalary = basicSalary + overtimePay - deductions,
                CreatedAt = DateTime.UtcNow,
               
            };

            _payrollServiceMock
                .Setup(s => s.GeneratePayrollAsync(
                    employeeId, startDate, endDate,
                    basicSalary, overtimePay, deductions))
                .ReturnsAsync(mockPayroll);

            // ── Act ───────────────────────────────────────────
            var result = await _payrollServiceMock.Object.GeneratePayrollAsync(
                employeeId, startDate, endDate,
                basicSalary, overtimePay, deductions);

            var grossSalary = result.BasicSalary + result.OvertimePay;

            // ── Assert ────────────────────────────────────────
            grossSalary.Should().Be(expectedGross);
            result.BasicSalary.Should().Be(basicSalary);
            result.OvertimePay.Should().Be(overtimePay);
            result.EmployeeID.Should().Be(employeeId);

            _payrollServiceMock.Verify(s => s.GeneratePayrollAsync(
                employeeId, startDate, endDate,
                basicSalary, overtimePay, deductions),
                Times.Once);
        }

        // ════════════════════════════════════════════════════════
        // TEST 2 — CalculateNetSalaryAfterDeductions
        // Objective: Net salary = BasicSalary + OvertimePay - Deductions
        // ════════════════════════════════════════════════════════

        [Test]
        public async Task CalculateNetSalaryAfterDeductions_ShouldReturnCorrectNetSalary()
        {
            // ── Arrange ───────────────────────────────────────
            var employeeId = "PX-EMP-202501-002";
            var startDate = new DateTime(2025, 2, 1);
            var endDate = new DateTime(2025, 2, 28);
            decimal basicSalary = 80000;
            decimal overtimePay = 20000;
            decimal deductions = 15000;
            decimal expectedNet = basicSalary + overtimePay - deductions; // 85000

            var mockPayroll = new Payroll
            {
                PayrollID = "PX-PAY-202502-001",
                EmployeeID = employeeId,
                PayPeriodStartDate = startDate,
                PayPeriodEndDate = endDate,
                BasicSalary = basicSalary,
                OvertimePay = overtimePay,
                Deductions = deductions,
                NetSalary = expectedNet,
                CreatedAt = DateTime.UtcNow,
               
            };

            _payrollServiceMock
                .Setup(s => s.GeneratePayrollAsync(
                    employeeId, startDate, endDate,
                    basicSalary, overtimePay, deductions))
                .ReturnsAsync(mockPayroll);

            // ── Act ───────────────────────────────────────────
            var result = await _payrollServiceMock.Object.GeneratePayrollAsync(
                employeeId, startDate, endDate,
                basicSalary, overtimePay, deductions);

            // ── Assert ────────────────────────────────────────
            result.NetSalary.Should().Be(expectedNet);
            result.NetSalary.Should().Be(result.BasicSalary + result.OvertimePay - result.Deductions);
            result.NetSalary.Should().BeGreaterThan(0);
            result.Deductions.Should().BeLessThan(result.BasicSalary + result.OvertimePay);

            _payrollServiceMock.Verify(s => s.GeneratePayrollAsync(
                employeeId, startDate, endDate,
                basicSalary, overtimePay, deductions),
                Times.Once);
        }

        // ════════════════════════════════════════════════════════
        // TEST 3 — VerifyTaxCalculationForHighIncomeEmployee
        // Objective: Test tax calculation for high income (30% slab)
        // ════════════════════════════════════════════════════════

        [Test]
        public async Task VerifyTaxCalculationForHighIncomeEmployee_ShouldCalculateCorrectTax()
        {
            // ── Arrange ───────────────────────────────────────
            var employeeId = "PX-EMP-202501-003";
            var taxYear = 2025;

            // High income — falls in 30% slab (above 10,00,000)
            decimal taxableIncome = 1500000;

            // Expected tax = 112500 + (1500000 - 1000000) * 30%
            //              = 112500 + 150000
            //              = 262500
            decimal expectedTax = 112500 + (taxableIncome - 1000000) * 0.30m;

            var mockTax = new Tax
            {
                TaxID = "PX-TAX-202501-001",
                EmployeeID = employeeId,
                TaxYear = taxYear,
                TaxableIncome = taxableIncome,
                TaxAmount = expectedTax,
                CreatedAt = DateTime.UtcNow
               
            };

            _taxServiceMock
                .Setup(s => s.CalculateTaxAsync(employeeId, taxYear))
                .ReturnsAsync(mockTax);

            // ── Act ───────────────────────────────────────────
            var result = await _taxServiceMock.Object
                .CalculateTaxAsync(employeeId, taxYear);

            // ── Assert ────────────────────────────────────────
            result.TaxAmount.Should().Be(expectedTax);
            result.TaxAmount.Should().Be(262500);
            result.TaxableIncome.Should().Be(taxableIncome);
            result.TaxYear.Should().Be(taxYear);
            result.TaxAmount.Should().BeGreaterThan(0);

            // Effective rate should be around 17.5%
            var effectiveRate = (result.TaxAmount / result.TaxableIncome) * 100;
            effectiveRate.Should().BeApproximately(17.5m, 0.1m);

            _taxServiceMock.Verify(s => s.CalculateTaxAsync(
                employeeId, taxYear), Times.Once);
        }

        // ════════════════════════════════════════════════════════
        // TEST 4 — ProcessPayrollForMultipleEmployees
        // Objective: Test end-to-end payroll for a batch of employees
        // ════════════════════════════════════════════════════════

        [Test]
        public async Task ProcessPayrollForMultipleEmployees_ShouldGeneratePayrollForAll()
        {
            // ── Arrange ───────────────────────────────────────
            var startDate = new DateTime(2025, 3, 1);
            var endDate = new DateTime(2025, 3, 31);

            var employees = new List<(string id, decimal basic, decimal overtime, decimal deductions)>
            {
                ("PX-EMP-202501-001", 50000,  5000, 3000),
                ("PX-EMP-202501-002", 80000, 10000, 8000),
                ("PX-EMP-202501-003", 120000, 20000, 15000)
            };

            var generatedPayrolls = new List<Payroll>();

            foreach (var (id, basic, overtime, ded) in employees)
            {
                var payroll = new Payroll
                {
                    PayrollID = $"PX-PAY-202503-00{employees.IndexOf((id, basic, overtime, ded)) + 1}",
                    EmployeeID = id,
                    PayPeriodStartDate = startDate,
                    PayPeriodEndDate = endDate,
                    BasicSalary = basic,
                    OvertimePay = overtime,
                    Deductions = ded,
                    NetSalary = basic + overtime - ded,
                    CreatedAt = DateTime.UtcNow
                   
                };

                generatedPayrolls.Add(payroll);

                _payrollServiceMock
                    .Setup(s => s.GeneratePayrollAsync(
                        id, startDate, endDate, basic, overtime, ded))
                    .ReturnsAsync(payroll);
            }

            // ── Act ───────────────────────────────────────────
            var results = new List<Payroll>();

            foreach (var (id, basic, overtime, ded) in employees)
            {
                var result = await _payrollServiceMock.Object.GeneratePayrollAsync(
                    id, startDate, endDate, basic, overtime, ded);
                results.Add(result);
            }

            // ── Assert ────────────────────────────────────────
            results.Should().HaveCount(3);
            results.Should().OnlyContain(p => p.NetSalary > 0);
            results.Should().OnlyContain(p => p.PayPeriodStartDate == startDate);
            results.Should().OnlyContain(p => p.PayPeriodEndDate == endDate);

            // Verify each net salary
            results[0].NetSalary.Should().Be(52000);   // 50000 + 5000 - 3000
            results[1].NetSalary.Should().Be(82000);   // 80000 + 10000 - 8000
            results[2].NetSalary.Should().Be(125000);  // 120000 + 20000 - 15000

            // Verify all payrolls have unique IDs
            results.Select(p => p.PayrollID).Should().OnlyHaveUniqueItems();

            _payrollServiceMock.Verify(s => s.GeneratePayrollAsync(
                 It.IsAny<string>(),
                 It.IsAny<DateTime>(),
                 It.IsAny<DateTime>(),
                 It.IsAny<decimal>(),
                 It.IsAny<decimal>(),
                 It.IsAny<decimal>()),
                 Times.Exactly(3));
        }

        // ════════════════════════════════════════════════════════
        // TEST 5 — VerifyErrorHandlingForInvalidEmployeeData
        // Objective: Ensure system handles invalid data gracefully
        // ════════════════════════════════════════════════════════

        [Test]
        public async Task VerifyErrorHandlingForInvalidEmployeeData_ShouldThrowExpectedException()
        {
            // ── Arrange ───────────────────────────────────────
            var invalidEmployeeId = "PX-EMP-INVALID-999";

            _employeeServiceMock
                .Setup(s => s.GetEmployeeByIdAsync(invalidEmployeeId))
                .ThrowsAsync(new EmployeeNotFoundException(invalidEmployeeId));

            _payrollServiceMock
                .Setup(s => s.GeneratePayrollAsync(
                    invalidEmployeeId,
                    It.IsAny<DateTime>(),
                    It.IsAny<DateTime>(),
                    It.IsAny<decimal>(),
                    It.IsAny<decimal>(),
                    It.IsAny<decimal>()))
                .ThrowsAsync(new EmployeeNotFoundException(invalidEmployeeId));

            _taxServiceMock
                .Setup(s => s.CalculateTaxAsync(invalidEmployeeId, It.IsAny<int>()))
                .ThrowsAsync(new EmployeeNotFoundException(invalidEmployeeId));

            // ── Act & Assert — Employee not found ─────────────
            var employeeEx = await FluentActions
                .Awaiting(() => _employeeServiceMock.Object
                    .GetEmployeeByIdAsync(invalidEmployeeId))
                .Should().ThrowAsync<EmployeeNotFoundException>();

            employeeEx.WithMessage($"*{invalidEmployeeId}*");

            // ── Act & Assert — Payroll for invalid employee ───
            var payrollEx = await FluentActions
                .Awaiting(() => _payrollServiceMock.Object
                    .GeneratePayrollAsync(
                        invalidEmployeeId,
                        DateTime.Now,
                        DateTime.Now.AddDays(30),
                        50000, 5000, 3000))
                .Should().ThrowAsync<EmployeeNotFoundException>();

            payrollEx.WithMessage($"*{invalidEmployeeId}*");

            // ── Act & Assert — Tax for invalid employee ───────
            var taxEx = await FluentActions
                .Awaiting(() => _taxServiceMock.Object
                    .CalculateTaxAsync(invalidEmployeeId, 2025))
                .Should().ThrowAsync<EmployeeNotFoundException>();

            taxEx.WithMessage($"*{invalidEmployeeId}*");

            // ── Verify all were called once ───────────────────
            _employeeServiceMock.Verify(s =>
                s.GetEmployeeByIdAsync(invalidEmployeeId), Times.Once);

            _payrollServiceMock.Verify(s => s.GeneratePayrollAsync(
                invalidEmployeeId,
                It.IsAny<DateTime>(),
                It.IsAny<DateTime>(),
                It.IsAny<decimal>(),
                It.IsAny<decimal>(),
                It.IsAny<decimal>()), Times.Once);

            _taxServiceMock.Verify(s =>
                s.CalculateTaxAsync(invalidEmployeeId, 2025), Times.Once);
        }
    }
}