﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PayXpert.Domain.Entities
{
    public class Payroll
    {
        // ── Primary Key ───────────────────────────────────────
        public string PayrollID { get; set; } = string.Empty;

        // ── Foreign Key ───────────────────────────────────────
        public string EmployeeID { get; set; } = string.Empty;

        // ── Pay Period ────────────────────────────────────────
        public DateTime PayPeriodStartDate { get; set; }
        public DateTime PayPeriodEndDate { get; set; }

        // ── Salary Details ────────────────────────────────────
        public decimal BasicSalary { get; set; }
        public decimal OvertimePay { get; set; }
        public decimal Deductions { get; set; }
        public decimal NetSalary { get; set; }

        // ── Audit Fields ──────────────────────────────────────
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
        public string CreatedBy { get; set; } = string.Empty;

        // ── Navigation Property ───────────────────────────────
        public Employee Employee { get; set; } = null!;
    }
}
