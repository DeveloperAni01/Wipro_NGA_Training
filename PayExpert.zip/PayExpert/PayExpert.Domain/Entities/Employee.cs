﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PayXpert.Domain.Entities
{
    public class Employee
    {
        // ── Primary Key ───────────────────────────────────────
        public string EmployeeID { get; set; } = string.Empty;

        // ── Personal Details ──────────────────────────────────
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public DateTime DateOfBirth { get; set; }
        public string Gender { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string PhoneNumber { get; set; } = string.Empty;
        public string Address { get; set; } = string.Empty;

        // ── Employment Details ────────────────────────────────
        public string Position { get; set; } = string.Empty;
        public DateTime JoiningDate { get; set; }
        public DateTime? TerminationDate { get; set; }
        public bool IsActive { get; set; } = true;

        // ── Audit Fields ──────────────────────────────────────
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
        public string CreatedBy { get; set; } = string.Empty;

        // ── Navigation Properties ─────────────────────────────
        public ICollection<Payroll> Payrolls { get; set; } = new List<Payroll>();
        public ICollection<Tax> Taxes { get; set; } = new List<Tax>();
        public ICollection<FinancialRecord> FinancialRecords { get; set; } = new List<FinancialRecord>();
    }
}
