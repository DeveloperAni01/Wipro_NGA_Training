﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PayXpert.Domain.Entities
{
    public class Tax
    {
        // ── Primary Key ───────────────────────────────────────
        public string TaxID { get; set; } = string.Empty;

        // ── Foreign Key ───────────────────────────────────────
        public string EmployeeID { get; set; } = string.Empty;

        // ── Tax Details ───────────────────────────────────────
        public int TaxYear { get; set; }
        public decimal TaxableIncome { get; set; }
        public decimal TaxAmount { get; set; }

        // ── Audit Fields ──────────────────────────────────────
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
        public string CreatedBy { get; set; } = string.Empty;

        // ── Navigation Property ───────────────────────────────
        public Employee Employee { get; set; } = null!;
    }
}
