﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PayXpert.Domain.Entities
{
    public class FinancialRecord
    {
        // ── Primary Key ───────────────────────────────────────
        public string RecordID { get; set; } = string.Empty;

        // ── Foreign Key ───────────────────────────────────────
        public string EmployeeID { get; set; } = string.Empty;

        // ── Record Details ────────────────────────────────────
        public DateTime RecordDate { get; set; }
        public string Description { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public string RecordType { get; set; } = string.Empty;

        // ── Audit Fields ──────────────────────────────────────
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
        public string CreatedBy { get; set; } = string.Empty;

        // ── Navigation Property ───────────────────────────────
        public Employee Employee { get; set; } = null!;
    }
}
